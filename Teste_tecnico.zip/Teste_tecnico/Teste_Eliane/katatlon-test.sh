#!/bin/bash
katalon-execute.sh -browserType=Chrome -retry=0 -statusDelay=15 -testSuitePath=TestSuites/TS_RegressionTest