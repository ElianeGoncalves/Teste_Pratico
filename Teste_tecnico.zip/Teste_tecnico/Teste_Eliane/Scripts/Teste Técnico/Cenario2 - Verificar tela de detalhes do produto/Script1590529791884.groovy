import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('http://automationpractice.com/index.php')

WebUI.click(findTestObject('Objetos_Cenario2/Page_My Store/botao_More'))

'//verifica se na pagina de detalhes é exibido preço.'
WebUI.verifyElementPresent(findTestObject('Objetos_Cenario2/Page_Faded Short Sleeve T-shirts - My Store/preco'), 0)

'//Clica no botão + e aumenta a quantidade de itens selecionados para compra'
WebUI.click(findTestObject('Objetos_Cenario2/Page_Faded Short Sleeve T-shirts - My Store/icone_aumenta_quantidade'))

WebUI.selectOptionByValue(findTestObject('Objetos_Cenario2/Page_Faded Short Sleeve T-shirts - My Store/select_tamanhos'), 
    '2', true)

WebUI.click(findTestObject('Objetos_Cenario2/Page_Faded Short Sleeve T-shirts - My Store/select_cor_azul'))

WebUI.click(findTestObject('Objetos_Cenario2/Page_Faded Short Sleeve T-shirts - My Store/botao_Add to cart'))

WebUI.verifyElementPresent(findTestObject('Objetos_Cenario2/Page_Faded Short Sleeve T-shirts - My Store/messagemAlerta_Product successfully added to your shopp_45f75f'), 
    0)

WebUI.click(findTestObject('Objetos_Cenario2/Page_Faded Short Sleeve T-shirts - My Store/botao_fecharPopUp'))

'//verifica se existem itens a serem comprados, caso verdadeiro, abre a tela que lista os itens para conclusão da compra'
if (true) {
    WebUI.click(findTestObject('Objetos_Cenario2/Page_Women - My Store/Page_My Store/b_Cart'))
}

