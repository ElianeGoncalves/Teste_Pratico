# healthcare-tests

Navigate to https://docs.katalon.com/katalon-studio/docs/health-care-prj.html for further details.
